const app = require("express")(),
    multer = require("multer"),
    storage = multer.diskStorage({
        //guardar el archivo con el nombre original
        destination:(req,file,cb) => {
            cb(null,"./archivos");
        },
        filename:(req,file,cb) =>{
            cb(null,file.originalname);
        }
    }),
    //upload = multer({dest: './archivos'});
    upload = multer({storage});

    app.get("/", (req,res) => {
        res.sendFile("/index.html", {root: __dirname});
    });

    app.post("/subir", upload.single("nombre_archivo"), (req,res) =>{
        console.log(req.file);
        res.send("archivo se subio correctamente");
    });

    //nota:podemos pasar despues del nombre separado por una , el limite de archivos que queremos subir
    app.post("/multiple", upload.array("nombre_archivo"),(req,res) => {
        console.log(req.file);
        res.send("los archivos se subieron bien");
    });


    app.listen(3000, () =>{
        console.log("servidor funcionando");
    });