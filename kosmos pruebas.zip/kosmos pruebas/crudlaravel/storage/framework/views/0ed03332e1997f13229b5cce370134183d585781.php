
<?php echo e($Modo == 'crear' ? 'Agregar empleado': 'Modificar empleado'); ?>

<div class="form-group">
<label for="nombre" class="control-label"><?php echo e('nombre'); ?></label>
<input class="form-control <?php echo e($errors->has('nombre')?'is-invalid':''); ?>" type="text" id="nombre" name="nombre" 
value="<?php echo e(isset($empleado->nombre) ? $empleado->nombre:old('nombre')); ?>">
<?php echo $errors->first('nombre','<div class="invalid-feedback">:message</div>'); ?>

</div>

<div class="form-group">
<label for="apellidopaterno" class="control-label"><?php echo e('apellidopaterno'); ?></label>
<input class="form-control <?php echo e($errors->has('apellidopaterno')?'is-invalid':''); ?>" type="text" id="apellidopaterno" name="apellidopaterno"
value="<?php echo e(isset($empleado->apellidopaterno) ? $empleado->apellidopaterno:old('apellidopaterno')); ?>">
<?php echo $errors->first('apellidopaterno','<div class="invalid-feedback">:message</div>'); ?>

</div>

<div class="form-group">
<label for="apellidomaterno" class="control-label"><?php echo e('apellidomaterno'); ?></label>
<input class="form-control <?php echo e($errors->has('apellidomaterno')?'is-invalid':''); ?>" type="text" id="apellidomaterno" name="apellidomaterno"
value="<?php echo e(isset($empleado->apellidomaterno) ? $empleado->apellidomaterno:old('apellidomaterno')); ?>">
<?php echo $errors->first('apellidomaterno','<div class="invalid-feedback">:message</div>'); ?>

</div>

<div class="form-group">
<label for="correo" class="control-label"><?php echo e('correo'); ?></label>
<input class="form-control <?php echo e($errors->has('correo')?'is-invalid':''); ?>" type="email" id="correo" name="correo"
value="<?php echo e(isset($empleado->correo) ? $empleado->correo:old('correo')); ?>">
<?php echo $errors->first('correo','<div class="invalid-feedback">:message</div>'); ?>

</div>

<?php if(isset($empleado->foto)): ?>
<img class="img-fluid" src="<?php echo e(asset('storage').'/'.$empleado->foto); ?>" alt="" width="100">
<?php endif; ?>

<div class="form-group">
<label for="foto" class="control-label"><?php echo e('foto'); ?></label>
<input class="form-control <?php echo e($errors->has('foto')?'is-invalid':''); ?>" type="file" id="foto" name="foto">
<?php echo $errors->first('foto','<div class="invalid-feedback">:message</div>'); ?>

</div>

<input class="btn btn-success" type="submit" name="" value="<?php echo e($Modo == 'crear' ? 'Agregar': 'Editar'); ?>">

<a href="<?php echo e(url('/empleados')); ?>" class="btn btn-primary">inicio</a>