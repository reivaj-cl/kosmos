<div class="form-group <?php echo e($errors->has('foto') ? 'has-error' : ''); ?>">
    <label for="foto" class="control-label"><?php echo e('Foto'); ?></label>
    <input class="form-control" name="foto" type="file" id="foto" value="<?php echo e(isset($trabajadore->foto) ? $trabajadore->foto : ''); ?>" >
    <?php echo $errors->first('foto', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('nombre') ? 'has-error' : ''); ?>">
    <label for="nombre" class="control-label"><?php echo e('Nombre'); ?></label>
    <input class="form-control" name="nombre" type="text" id="nombre" value="<?php echo e(isset($trabajadore->nombre) ? $trabajadore->nombre : ''); ?>" >
    <?php echo $errors->first('nombre', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('apellidopaterno') ? 'has-error' : ''); ?>">
    <label for="apellidopaterno" class="control-label"><?php echo e('Apellidopaterno'); ?></label>
    <input class="form-control" name="apellidopaterno" type="text" id="apellidopaterno" value="<?php echo e(isset($trabajadore->apellidopaterno) ? $trabajadore->apellidopaterno : ''); ?>" >
    <?php echo $errors->first('apellidopaterno', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('apellidomaterno') ? 'has-error' : ''); ?>">
    <label for="apellidomaterno" class="control-label"><?php echo e('Apellidomaterno'); ?></label>
    <input class="form-control" name="apellidomaterno" type="text" id="apellidomaterno" value="<?php echo e(isset($trabajadore->apellidomaterno) ? $trabajadore->apellidomaterno : ''); ?>" >
    <?php echo $errors->first('apellidomaterno', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('correo') ? 'has-error' : ''); ?>">
    <label for="correo" class="control-label"><?php echo e('Correo'); ?></label>
    <input class="form-control" name="correo" type="email" id="correo" value="<?php echo e(isset($trabajadore->correo) ? $trabajadore->correo : ''); ?>" >
    <?php echo $errors->first('correo', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
