<?php $__env->startSection('content'); ?>
<div class="container">
<?php if(Session::has('Mensaje')): ?>
<div class="alert alert-success" role="alert">
    <?php echo e(Session::get('Mensaje')); ?>

</div>

<?php endif; ?>
<a href="<?php echo e(url('/empleados/create')); ?>" class="btn btn-success">Agregar empleado</a>

<table class="table table-light table-hover">
    <thead class="thead-light">
        <tr>
            <th>#</th>
            <th>foto</th>
            <th>nombre completo</th>
            <th>correo</th>
           <th>acciones</th>
        </tr>
    </thead>
    <tbody>
    
    <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td>
                <img class="img-thumbnail img-fluid " src="<?php echo e(asset('storage').'/'.$empleado->foto); ?>" alt="" width="100">
            </td>
            <td><?php echo e($empleado->nombre); ?> <?php echo e($empleado->apellidopaterno); ?> <?php echo e($empleado->apellidomaterno); ?></td>
            <td><?php echo e($empleado->correo); ?></td>
            <td>
                <a href="<?php echo e(url('/empleados/'.$empleado->id.'/edit')); ?>" class="btn btn-warning">Editar</a>
                <form method="post" action="<?php echo e(url('/empleados/'.$empleado->id)); ?>" style="display:inline;">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('DELETE')); ?>

                    <button type="submit" onclick="return confirm('¿borrar?');" class="btn btn-danger">Borrar</button>
                </form>
            </td>
        </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  
</table>

<?php echo e($empleados->links()); ?>


<div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>