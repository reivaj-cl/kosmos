<?php $__env->startSection('content'); ?>
<div class="container">
<?php if(count($errors) > 0): ?>
<div class="alert alert-primary" role="alert">
    <ul>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <li><?php echo e($error); ?></li>        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>
<form method="post" action="<?php echo e(url('/empleados')); ?>" enctype="multipart/form-data" class="form-horizontal">
 <?php echo e(csrf_field()); ?>

 <?php echo $__env->make('empleados.form',['Modo' => 'crear'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
   </form>
<div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>