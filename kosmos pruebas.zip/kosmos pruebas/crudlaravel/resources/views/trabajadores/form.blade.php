<div class="form-group {{ $errors->has('foto') ? 'has-error' : ''}}">
    <label for="foto" class="control-label">{{ 'Foto' }}</label>
    <input class="form-control" name="foto" type="file" id="foto" value="{{ isset($trabajadore->foto) ? $trabajadore->foto : ''}}" >
    {!! $errors->first('foto', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('nombre') ? 'has-error' : ''}}">
    <label for="nombre" class="control-label">{{ 'Nombre' }}</label>
    <input class="form-control" name="nombre" type="text" id="nombre" value="{{ isset($trabajadore->nombre) ? $trabajadore->nombre : ''}}" >
    {!! $errors->first('nombre', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('apellidopaterno') ? 'has-error' : ''}}">
    <label for="apellidopaterno" class="control-label">{{ 'Apellidopaterno' }}</label>
    <input class="form-control" name="apellidopaterno" type="text" id="apellidopaterno" value="{{ isset($trabajadore->apellidopaterno) ? $trabajadore->apellidopaterno : ''}}" >
    {!! $errors->first('apellidopaterno', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('apellidomaterno') ? 'has-error' : ''}}">
    <label for="apellidomaterno" class="control-label">{{ 'Apellidomaterno' }}</label>
    <input class="form-control" name="apellidomaterno" type="text" id="apellidomaterno" value="{{ isset($trabajadore->apellidomaterno) ? $trabajadore->apellidomaterno : ''}}" >
    {!! $errors->first('apellidomaterno', '<p class="help-block">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('correo') ? 'has-error' : ''}}">
    <label for="correo" class="control-label">{{ 'Correo' }}</label>
    <input class="form-control" name="correo" type="email" id="correo" value="{{ isset($trabajadore->correo) ? $trabajadore->correo : ''}}" >
    {!! $errors->first('correo', '<p class="help-block">:message</p>') !!}
</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="{{ $formMode === 'edit' ? 'Update' : 'Create' }}">
</div>
