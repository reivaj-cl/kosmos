
{{ $Modo == 'crear' ? 'Agregar empleado': 'Modificar empleado' }}
<div class="form-group">
<label for="nombre" class="control-label">{{'nombre'}}</label>
<input class="form-control {{$errors->has('nombre')?'is-invalid':''}}" type="text" id="nombre" name="nombre" 
value="{{ isset($empleado->nombre) ? $empleado->nombre:old('nombre')}}">
{!! $errors->first('nombre','<div class="invalid-feedback">:message</div>') !!}
</div>

<div class="form-group">
<label for="apellidopaterno" class="control-label">{{'apellidopaterno'}}</label>
<input class="form-control {{$errors->has('apellidopaterno')?'is-invalid':''}}" type="text" id="apellidopaterno" name="apellidopaterno"
value="{{ isset($empleado->apellidopaterno) ? $empleado->apellidopaterno:old('apellidopaterno')}}">
{!! $errors->first('apellidopaterno','<div class="invalid-feedback">:message</div>') !!}
</div>

<div class="form-group">
<label for="apellidomaterno" class="control-label">{{'apellidomaterno'}}</label>
<input class="form-control {{$errors->has('apellidomaterno')?'is-invalid':''}}" type="text" id="apellidomaterno" name="apellidomaterno"
value="{{ isset($empleado->apellidomaterno) ? $empleado->apellidomaterno:old('apellidomaterno')}}">
{!! $errors->first('apellidomaterno','<div class="invalid-feedback">:message</div>') !!}
</div>

<div class="form-group">
<label for="correo" class="control-label">{{'correo'}}</label>
<input class="form-control {{$errors->has('correo')?'is-invalid':''}}" type="email" id="correo" name="correo"
value="{{ isset($empleado->correo) ? $empleado->correo:old('correo')}}">
{!! $errors->first('correo','<div class="invalid-feedback">:message</div>') !!}
</div>

@if(isset($empleado->foto))
<img class="img-fluid" src="{{ asset('storage').'/'.$empleado->foto}}" alt="" width="100">
@endif

<div class="form-group">
<label for="foto" class="control-label">{{'foto'}}</label>
<input class="form-control {{$errors->has('foto')?'is-invalid':''}}" type="file" id="foto" name="foto">
{!! $errors->first('foto','<div class="invalid-feedback">:message</div>') !!}
</div>

<input class="btn btn-success" type="submit" name="" value="{{ $Modo == 'crear' ? 'Agregar': 'Editar' }}">

<a href="{{ url('/empleados')}}" class="btn btn-primary">inicio</a>