@extends('layouts.app')

@section('content')
<div class="container">
<form method="post" action="{{ url('/empleados/'.$empleado->id) }}" enctype="multipart/form-data" class="form-horizontal">
 {{ csrf_field()  }}
  {{ method_field('PATCH')  }}

   @include('empleados.form',['Modo' => 'editar']);
</form>
<div>
@endsection